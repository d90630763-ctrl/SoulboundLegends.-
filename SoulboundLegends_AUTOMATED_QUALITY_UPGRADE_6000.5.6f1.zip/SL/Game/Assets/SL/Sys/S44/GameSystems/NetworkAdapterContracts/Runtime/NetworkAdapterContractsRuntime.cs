using System;
using System.Collections.Generic;
using UnityEngine;

namespace GameSystems.NetworkAdapterContracts
{
    [CreateAssetMenu(fileName = "NetworkAdapterContractsConfig", menuName = "Game Systems/Network Adapter Contracts/Config")]
    public sealed class NetworkAdapterContractsConfig : ScriptableObject
    {
        public string systemId = "SYS-44";
        public bool enabledInBuild = true;
        [Min(0.001f)] public float serverRequestTimeout = 5f;
        [Min(1)] public int maxRequestsPerSecond = 20;
        [TextArea(2,6)] public string designNotes;
    }

    [Serializable]
    public sealed class NetworkAdapterContractsRequest
    {
        public string requestId;
        public string entityId;
        public string action;
        public long clientSequence;
        public string payloadJson;
    }

    [Serializable]
    public sealed class NetworkAdapterContractsResult
    {
        public bool accepted;
        public string requestId;
        public string reason;
        public long authoritativeSequence;
    }

    public interface INetworkAdapterContractsAuthority
    {
        NetworkAdapterContractsResult ValidateAndExecute(NetworkAdapterContractsRequest request);
    }

    public sealed class NetworkAdapterContractsRuntime : MonoBehaviour
    {
        [SerializeField] private NetworkAdapterContractsConfig config;
        private readonly HashSet<string> processedRequests = new HashSet<string>();

        public NetworkAdapterContractsConfig Config => config;

        public void Initialize(NetworkAdapterContractsConfig value)
        {
            config = value;
            if (config == null) throw new ArgumentNullException(nameof(value));
        }

        public bool TryAcceptRequest(NetworkAdapterContractsRequest request, out NetworkAdapterContractsResult result)
        {
            result = new NetworkAdapterContractsResult { requestId = request != null ? request.requestId : string.Empty };
            if (request == null) { result.reason = "null_request"; return false; }
            if (string.IsNullOrWhiteSpace(request.requestId)) { result.reason = "missing_request_id"; return false; }
            if (processedRequests.Contains(request.requestId)) { result.reason = "duplicate_request"; return false; }
            processedRequests.Add(request.requestId);
            result.accepted = true;
            result.reason = "accepted";
            return true;
        }
    }
}
